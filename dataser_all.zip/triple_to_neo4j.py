import csv  # 导入csv文件
import py2neo  # 导入py2neo库
from py2neo import Graph, Node, Relationship, NodeMatcher

g = Graph("http://localhost:7474", auth=("neo4j", "1234"))  # 连接neo4j，将'xxx'分别改为你的用户名和密码
g.delete_all()  # 清除neo4j中原有的结点等所有信息

with open('dataOfcase1.csv', 'r') as f:
    reader = csv.reader(f)
    for item in reader:
        # if reader.line_num==1:
        #    continue
        """构建context之间的关系"""
        # print("当前行数：", reader.line_num, "当前内容：", item)
        start_node = Node("r0", name=item[0])
        end_node = Node("r1", value=item[2])
        relation = Relationship(start_node, "Contain", end_node)
        g.merge(start_node, "r0", "name")
        g.merge(end_node, "r1", "value")
        g.merge(relation, "Contain", "属性")

        start_node = Node("r1", name=item[3])
        end_node = Node("r1", value=item[5])
        relation = Relationship(start_node, "Derive", end_node)
        g.merge(start_node, "r1", "name")
        g.merge(end_node, "r1", "value")
        g.merge(relation, "Derive", "属性")

        start_node = Node("r1", name=item[6])
        end_node = Node("actor", value=item[8])
        relation = Relationship(start_node, "From", end_node)
        g.merge(start_node, "r1", "name")
        g.merge(end_node, "actor", "value")
        g.merge(relation, "From", "属性")

        start_node = Node("r1", name=item[9])
        end_node = Node("product", value=item[11])
        relation = Relationship(start_node, "Rely", end_node)
        g.merge(start_node, "r1", "name")
        g.merge(end_node, "prodcut", "value")
        g.merge(relation, "Rely", "属性")

 #注意缩进

